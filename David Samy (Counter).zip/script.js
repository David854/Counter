let count = 0;

const counterElement = document.querySelector("#counter");
const incrementButton = document.querySelector("#plus");
const decrementButton = document.querySelector("#minus");
const resetButton = document.querySelector("#reset");

incrementButton.addEventListener('click', () => {
    count++;
    updateCounter();
});

decrementButton.addEventListener('click', () => {
    count--;
    updateCounter();
});

resetButton.addEventListener('click', () => {
    count = 0;
    updateCounter();
});

function updateCounter() {
    counterElement.textContent = count;
}